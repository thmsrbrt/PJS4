create definer = lngeth@localhost view v_candidat as
select `pjs4`.`utilisateur`.`idUtilisateur` AS `idUtilisateur`,
       `pjs4`.`utilisateur`.`Prenom`        AS `Prenom`,
       `pjs4`.`utilisateur`.`Nom`           AS `Nom`,
       `pjs4`.`utilisateur`.`Email`         AS `Email`,
       `pjs4`.`utilisateur`.`MotDePasse`    AS `MotDePasse`,
       `pjs4`.`utilisateur`.`PhotoProfile`  AS `PhotoProfile`,
       `pjs4`.`utilisateur`.`Description`   AS `Description`,
       `pjs4`.`utilisateur`.`CVFile`        AS `CVFile`,
       `pjs4`.`utilisateur`.`Type`          AS `Type`
from `pjs4`.`utilisateur`
where (`pjs4`.`utilisateur`.`Type` = 'Candidat');

