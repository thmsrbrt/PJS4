create definer = lngeth@localhost trigger T_IncrementeNbCandidature
    after insert
    on candidature
    for each row
BEGIN
       UPDATE Annonce SET NbCandidat = NbCandidat + 1
       WHERE Annonce.idAnnonce = NEW.IdAnnonce;
    end;

