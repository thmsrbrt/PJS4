create definer = lngeth@localhost view v_entreprise as
select `pjs4`.`utilisateur`.`idUtilisateur` AS `idUtilisateur`,
       `pjs4`.`utilisateur`.`Nom`           AS `Nom`,
       `pjs4`.`utilisateur`.`Email`         AS `Email`,
       `pjs4`.`utilisateur`.`MotDePasse`    AS `MotDePasse`,
       `pjs4`.`utilisateur`.`PhotoProfile`  AS `PhotoProfile`,
       `pjs4`.`utilisateur`.`Type`          AS `Type`
from `pjs4`.`utilisateur`
where (`pjs4`.`utilisateur`.`Type` = 'Entreprise');

